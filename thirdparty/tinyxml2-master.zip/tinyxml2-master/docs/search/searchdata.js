var indexSectionsWithContent =
{
  0: "abcdefghilnopqrstuvx",
  1: "x",
  2: "abcdefghilnopqrstuvx",
  3: "glprt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Pages"
};

